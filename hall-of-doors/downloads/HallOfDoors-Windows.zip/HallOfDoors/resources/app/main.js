const { app, BrowserWindow, Menu, shell } = require('electron');
app.commandLine.appendSwitch('ignore-gpu-blocklist');
app.commandLine.appendSwitch('allow-file-access-from-files');
app.whenReady().then(() => {
  Menu.setApplicationMenu(null);
  const w = new BrowserWindow({ width: 1280, height: 800, backgroundColor: '#07060c', title: 'Hall of Doors', icon: require('path').join(__dirname, 'icons', 'icon-512.png'), autoHideMenuBar: true, show: false, webPreferences: { contextIsolation: true, webSecurity: false } });
  w.webContents.setWindowOpenHandler(({ url }) => { if (/^https?:/.test(url)) shell.openExternal(url); return { action: 'deny' }; });
  w.webContents.on('will-navigate', (e, url) => { if (/^https?:/.test(url)) { e.preventDefault(); shell.openExternal(url); } });
  w.loadFile('index.html');
  w.once('ready-to-show', () => { w.maximize(); w.show(); });
  w.webContents.on('before-input-event', (e, i) => { if (i.type === 'keyDown' && i.key === 'F11') { w.setFullScreen(!w.isFullScreen()); e.preventDefault(); } });
});
app.on('window-all-closed', () => app.quit());
